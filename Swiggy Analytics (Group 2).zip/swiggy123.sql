create database swiggy;
use `swiggy`;

CREATE TABLE Customer (
    Customer_ID INT PRIMARY KEY,
    Name VARCHAR(100),
    Mobile VARCHAR(20),
    Email VARCHAR(100),
    Gender ENUM('Male', 'Female', 'Other'),
    DOB DATE,
    Membership_Status ENUM('Gold', 'Platinum','Regular'),
    Loyalty_Points INT
);

UPDATE Customer
SET Mobile = CONCAT(
    '+91 ',
    RIGHT(
        CASE
            -- already starts with +91
            WHEN Mobile LIKE '+91%' THEN SUBSTRING(Mobile, 4)

            -- starts with 91 (no +)
            WHEN Mobile LIKE '91%' THEN SUBSTRING(Mobile, 3)

            -- otherwise keep as is
            ELSE Mobile
        END,
        10
    )
);

select * from customer;


CREATE TABLE Customer_Address (
    Customer_Address_ID INT PRIMARY KEY,
    Customer_ID INT,
    Address VARCHAR(255),
    City VARCHAR(50),
    Pin_Code VARCHAR(10),
    Address_Type ENUM('Home', 'Work'),
    FOREIGN KEY (Customer_ID) REFERENCES Customer(Customer_ID)
);

select * from customer_address;
                            
CREATE TABLE Restaurant (
    Restaurant_ID INT PRIMARY KEY,
    Name VARCHAR(100),
    Location VARCHAR(100),
    Cuisine_Type VARCHAR(50),
    Average_Rating DECIMAL(2,1),
    Total_Reviews INT
);                            

select * from restaurant;

CREATE TABLE Menu (
    Menu_Item_ID INT PRIMARY KEY,
    Restaurant_ID INT,
    Item_Name VARCHAR(100),
    Category ENUM('Starter', 'Main Course', 'Beverage', 'Dessert'),
    Price DECIMAL(8,2),
    Calories INT,
    FOREIGN KEY (Restaurant_ID) REFERENCES Restaurant(Restaurant_ID)
);

select * from menu;

CREATE TABLE Orders (
    Order_ID INT PRIMARY KEY,
    Customer_ID INT,
    Restaurant_ID INT,
    Order_Date DATE,
    Total_Amount DECIMAL(10,2),
    payment_method varchar(100),
    Status ENUM('Placed', 'Preparing', 'Out for Delivery', 'Delivered', 'Cancelled'),
    FOREIGN KEY (Customer_ID) REFERENCES Customer(Customer_ID),
    FOREIGN KEY (Restaurant_ID) REFERENCES Restaurant(Restaurant_ID)
);
drop table orders;

ALTER TABLE orders
MODIFY order_id INT NOT NULL AUTO_INCREMENT;

alter table orders
drop column paymentmethod;

alter table orders
add column paymentmethod ENUM("Cash on Delivery", "UPI", "Credit Card", "Debit Card");


CREATE TABLE Delivery_Agent (
    Delivery_Agent_ID INT PRIMARY KEY,
    Name VARCHAR(100),
    Mobile VARCHAR(20),
    Vehicle_Type ENUM('Bike', 'Scooter', 'Bicycle'),
    Ratings DECIMAL(2,1)
);
drop table delivery_agent;
UPDATE Customer
SET Mobile = CONCAT(
    '+91 ',
    RIGHT(
        CASE
            -- already starts with +91
            WHEN Mobile LIKE '+91%' THEN SUBSTRING(Mobile, 4)

            -- starts with 91 (no +)
            WHEN Mobile LIKE '91%' THEN SUBSTRING(Mobile, 3)

            -- otherwise keep as is
            ELSE Mobile
        END,
        10
    )
);

select * from delivery_agent;

CREATE TABLE Delivery (
    Delivery_ID INT PRIMARY KEY,
    Order_ID INT,
    Delivery_Agent_ID INT,
    Delivery_Status ENUM('Cancelled', 'Late', 'On Time'),
    Delivery_Feedback_Rating INT,
    FOREIGN KEY (Order_ID) REFERENCES Orders(Order_ID),
    FOREIGN KEY (Delivery_Agent_ID) REFERENCES Delivery_Agent(Delivery_Agent_ID)
);
DROP TABLE DELIVERY;
select * from login_audit;

CREATE TABLE Login_Audit (
    Login_Audit_ID INT PRIMARY KEY,
    Customer_ID INT,
    Login_Time DATETIME,
    Logout_Time DATETIME,
    Login_Method ENUM('Email', 'Google', 'Facebook'),
    FOREIGN KEY (Customer_ID) REFERENCES Customer(Customer_ID)
);
